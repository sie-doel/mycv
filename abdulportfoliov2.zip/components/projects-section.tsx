"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ExternalLink, Github, Video } from "lucide-react"
import VideoPortfolioModal from "./video-portfolio-modal"

export default function ProjectsSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [activeTab, setActiveTab] = useState("all")
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  const projects = [
    {
      title: "Literary Soul - Indonesian Writings",
      description:
        "A beautiful literary platform showcasing heartfelt Indonesian writings including poetry, short stories, essays, and philosophical poetry with search functionality and English translations.",
      image:
        "https://sjc.microlink.io/gHqiNdBMIog-L75fIjRdRGkS8q6xYU21MtBsC6pcOgujvadOKGEGs42erCXYck3S4j2VBMUc4iKMnNLdNn3tMA.jpeg",
      category: "writing",
      tags: ["Creative Writing", "Indonesian Literature", "Poetry", "Web Platform", "Content Management"],
      link: "https://v0-custom-blog-display.vercel.app/",
      github: "#",
    },
    {
      title: "IMDb Top 1000 Movies Analysis",
      description:
        "Comprehensive data analysis of IMDb's top 1000 movies exploring genre trends, ratings, and box office insights using R programming and statistical analysis.",
      image:
        "https://sjc.microlink.io/kIPTN7ny5zKYoFHV0lnm_NABowYmz7wen1mPwTmZPhuROm-V5m7ZD7bU2njvkGDcM7ML87Z3W0YDVJIM1aYAUg.jpeg",
      category: "data",
      tags: ["R Programming", "Data Analysis", "ggplot2", "tidyverse", "Statistical Analysis"],
      link: "https://v0-abdul-ghofur-portfolio-wu.vercel.app/",
      github: "#",
    },
    {
      title: "Best Selling Books Dashboard",
      description:
        "Interactive dashboard analyzing the world's most popular books with comprehensive sales data, author information, and publication trends across different languages and time periods.",
      image:
        "https://sjc.microlink.io/aZuzbM_pbMuJ4AkoKZEA8lwnOt2N6InuCY_JMKl1krEDATE9H8aYbmcdNFH9fQedLTdVExYz5Ijgle4PuZjTdA.jpeg",
      category: "data",
      tags: ["Data Visualization", "Dashboard Design", "Interactive Charts", "Book Analytics"],
      link: "https://v0-best-selling-books-dashboard.vercel.app/",
      github: "#",
    },
    {
      title: "Indonesian Workforce Analysis Dashboard",
      description:
        "Comprehensive interactive dashboard analyzing Indonesia's workforce data for 2024, featuring job seeker statistics, vacancy trends, placement rates, and demographic breakdowns by province and gender.",
      image:
        "https://sjc.microlink.io/9J7b891T2-UfRLiVHXGH3aYaO1-UBKGIWJjsGzQm-PNBUmKMaFIqMfxwHQqRJ26EBgG5yOXxhUD4wacyeXOEoQ.jpeg",
      category: "data",
      tags: [
        "Data Visualization",
        "Statistical Analysis",
        "Interactive Dashboard",
        "Workforce Analytics",
        "Indonesian Data",
      ],
      link: "https://v0-interactive-dashboard-zeta.vercel.app/",
      github: "#",
    },
    {
      title: "Indonesia Tobacco Consumption Dashboard",
      description:
        "Comprehensive analysis and visualization of tobacco consumption patterns in Indonesia (2022-2024). Features public expenditure analysis, consumption trends, and interactive data visualizations for public health insights.",
      image:
        "https://sjc.microlink.io/0rmUdQsVuCeXArHjZqOxkd_6Ai9xtU2pyabCE4ntIAjU_RdwYM4x1uOKfcm6JCbDozcpm5T696av1P-9VW_pfQ.jpeg",
      category: "data",
      tags: [
        "Public Health Analytics",
        "Economic Analysis",
        "Data Visualization",
        "Indonesian Statistics",
        "Interactive Dashboard",
        "Consumption Patterns",
      ],
      link: "https://v0-indonesia-tobacco-dashboard.vercel.app/",
      github: "#",
    },
    {
      title: "YOLOv8 Real-Time Person Tracking & Counting",
      description:
        "Advanced computer vision system for real-time person detection, tracking, and counting via webcam. Features color detection capabilities and is optimized for CCTV applications, footfall counting, and basic video analytics.",
      image: "/placeholder.svg?height=200&width=400",
      category: "data",
      tags: [
        "YOLOv8",
        "Computer Vision",
        "ByteTrack",
        "OpenCV",
        "Real-time Processing",
        "Object Detection",
        "Video Analytics",
        "AI/ML",
      ],
      link: "https://github.com/sie-doel/YOLOv8-Person-Tracking-Counting-Color.git",
      github: "https://github.com/sie-doel/YOLOv8-Person-Tracking-Counting-Color.git",
    },
    {
      title: "EJR Digital Attendance System",
      description:
        "A comprehensive digital attendance system for EJR Entertainment Group's Sayur Mayur Division. Features user authentication, real-time attendance tracking, and administrative dashboard with Supabase backend integration.",
      image:
        "https://sjc.microlink.io/OusHfgG28VyyaCH8JF3rmPUOi43WvvoelwIXqiB1wS8R0CHrS3ZEDsbhJy3Y0v8VVKNh88sgvQ3HBJaR-vxUVw.jpeg",
      category: "data",
      tags: ["React", "Supabase", "Authentication", "Real-time Database", "Attendance Management", "Dashboard"],
      link: "https://v0-supabase-react-app-eight.vercel.app/",
      github: "#",
    },
    {
      title: "E-Sports Tournament Platform",
      description: "A platform for managing e-sports tournaments for Mobile Legends, Free Fire, and eFootball.",
      image: "/placeholder.svg?height=200&width=400",
      category: "esports",
      tags: ["React", "Node.js", "MongoDB"],
      link: "#",
      github: "#",
    },
    {
      title: "Travel Expedition Management",
      description: "System for managing intercity expedition services and trip planning.",
      image: "/placeholder.svg?height=200&width=400",
      category: "travel",
      tags: ["React", "Express", "PostgreSQL"],
      link: "#",
      github: "#",
    },
    {
      title: "Video Portfolio Showcase",
      description: "A showcase of videography and photography projects with filtering capabilities.",
      image: "/placeholder.svg?height=200&width=400",
      category: "media",
      tags: ["Next.js", "Tailwind CSS", "Framer Motion"],
      link: "#",
      github: "#",
      isVideoPortfolio: true,
    },
    {
      title: "Community Management Platform",
      description: "Platform for managing e-sports community members, events, and communications.",
      image: "/placeholder.svg?height=200&width=400",
      category: "esports",
      tags: ["Vue.js", "Firebase", "Tailwind CSS"],
      link: "#",
      github: "#",
    },
  ]

  const filteredProjects = activeTab === "all" ? projects : projects.filter((project) => project.category === activeTab)

  const projectVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      },
    }),
  }

  return (
    <>
      <section id="projects" className="py-20 bg-gray-50 dark:bg-gray-900 rounded-lg" ref={ref}>
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Projects</h2>
            <div className="w-20 h-1 bg-black dark:bg-white mx-auto mb-8"></div>
            <p className="max-w-3xl mx-auto text-base md:text-lg text-gray-700 dark:text-gray-300 leading-relaxed text-left md:text-center px-4">
              A selection of my work across different domains and technologies.
            </p>
          </div>

          <Tabs defaultValue="all" className="mb-12" onValueChange={setActiveTab}>
            <div className="flex justify-center">
              <TabsList className="bg-gray-200 dark:bg-gray-800">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="writing">Writing</TabsTrigger>
                <TabsTrigger value="data">Data Analysis</TabsTrigger>
                <TabsTrigger value="esports">E-Sports</TabsTrigger>
                <TabsTrigger value="travel">Travel</TabsTrigger>
                <TabsTrigger value="media">Media</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value={activeTab} className="mt-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProjects.map((project, i) => (
                  <motion.div
                    key={i}
                    custom={i}
                    variants={projectVariants}
                    initial="hidden"
                    animate={inView ? "visible" : "hidden"}
                  >
                    <Card className="h-full overflow-hidden hover:shadow-lg transition-shadow duration-300 border-none">
                      <div className="h-48 overflow-hidden">
                        <img
                          src={project.image || "/placeholder.svg"}
                          alt={project.title}
                          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                        />
                      </div>
                      <CardHeader>
                        <CardTitle className="text-base md:text-lg leading-tight">{project.title}</CardTitle>
                        <CardDescription className="text-xs md:text-sm leading-relaxed text-left">
                          {project.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2 mt-2">
                          {project.tags.map((tag, j) => (
                            <Badge
                              key={j}
                              variant="outline"
                              className="bg-gray-100 text-black border-gray-300 dark:bg-gray-800 dark:text-white dark:border-gray-700 text-xs"
                            >
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter className="flex flex-wrap gap-2 justify-between">
                        <Button variant="outline" size="sm" asChild>
                          <a href={project.github} target="_blank" rel="noopener noreferrer">
                            <Github className="mr-2 h-4 w-4" /> Code
                          </a>
                        </Button>
                        {project.isVideoPortfolio ? (
                          <Button
                            className="bg-black hover:bg-gray-800 text-white"
                            size="sm"
                            onClick={() => setIsVideoModalOpen(true)}
                          >
                            <Video className="mr-2 h-4 w-4" /> View Gallery
                          </Button>
                        ) : (
                          <Button className="bg-black hover:bg-gray-800 text-white" size="sm" asChild>
                            <a href={project.link} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="mr-2 h-4 w-4" /> View Project
                            </a>
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <VideoPortfolioModal isOpen={isVideoModalOpen} onClose={() => setIsVideoModalOpen(false)} />
    </>
  )
}
