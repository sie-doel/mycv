import Link from "next/link"
import { Mail, Phone, Instagram, Github, Linkedin, Twitter, Gamepad, MapPin } from "lucide-react"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-100 dark:bg-gray-900 py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Link href="/" className="font-bold text-2xl">
              Abdul<span className="text-black dark:text-white">Ghofur</span>
            </Link>
            <p className="mt-2 text-gray-600 dark:text-gray-400 max-w-md">
              Junior Data Analyst | Aspiring Videographer | E-Sports Community Founder
            </p>
            <div className="flex items-center mt-2 text-gray-600 dark:text-gray-400">
              <MapPin className="h-4 w-4 mr-1" />
              <span>Samarinda, East Kalimantan, Indonesia</span>
            </div>
          </div>

          <div className="flex space-x-4">
            <a
              href="mailto:abdulpaintar@gmail.com"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="Email"
            >
              <Mail className="h-5 w-5" />
            </a>
            <a
              href="https://wa.me/6285845134291"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="WhatsApp"
            >
              <Phone className="h-5 w-5" />
            </a>
            <a
              href="https://instagram.com/go_fury_"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="Instagram"
            >
              <Instagram className="h-5 w-5" />
            </a>
            <a
              href="https://www.instagram.com/ejr_entertainment.group/"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="EJR Entertainment"
            >
              <Gamepad className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="GitHub"
            >
              <Github className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin className="h-5 w-5" />
            </a>
            <a
              href="#"
              className="h-10 w-10 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center hover:bg-black hover:text-white dark:hover:bg-gray-800 transition-colors"
              aria-label="Twitter"
            >
              <Twitter className="h-5 w-5" />
            </a>
          </div>
        </div>

        <div className="border-t border-gray-300 dark:border-gray-700 mt-8 pt-8 text-center">
          <p className="text-gray-600 dark:text-gray-400">&copy; {currentYear} Abdul Ghofur. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
