"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import { Gamepad2, Camera, Music, Book, Plane, Code, Palette, Users } from "lucide-react"

export default function HobbiesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const hobbies = [
    {
      icon: <Gamepad2 className="h-8 w-8 text-black dark:text-white" />,
      title: "Gaming",
      description: "Passionate about competitive gaming, especially Mobile Legends and Free Fire",
    },
    {
      icon: <Camera className="h-8 w-8 text-black dark:text-white" />,
      title: "Photography",
      description: "Capturing moments and creating visual stories through photography",
    },
    {
      icon: <Code className="h-8 w-8 text-black dark:text-white" />,
      title: "Coding",
      description: "Exploring new technologies and building creative projects",
    },
    {
      icon: <Plane className="h-8 w-8 text-black dark:text-white" />,
      title: "Travel",
      description: "Discovering new places and experiencing different cultures",
    },
    {
      icon: <Music className="h-8 w-8 text-black dark:text-white" />,
      title: "Music",
      description: "Listening to various genres and discovering new artists",
    },
    {
      icon: <Book className="h-8 w-8 text-black dark:text-white" />,
      title: "Learning",
      description: "Continuously learning new skills and expanding knowledge",
    },
    {
      icon: <Users className="h-8 w-8 text-black dark:text-white" />,
      title: "Community Building",
      description: "Building and nurturing communities around shared interests",
    },
    {
      icon: <Palette className="h-8 w-8 text-black dark:text-white" />,
      title: "Creative Design",
      description: "Exploring visual design and creative content creation",
    },
  ]

  const hobbyVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      },
    }),
  }

  return (
    <section id="hobbies" className="py-20 bg-gray-50 dark:bg-gray-900 rounded-lg" ref={ref}>
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Hobbies & Interests</h2>
          <div className="w-20 h-1 bg-black dark:bg-white mx-auto mb-8"></div>
          <p className="max-w-3xl mx-auto text-lg text-gray-700 dark:text-gray-300">
            Beyond work, these are the activities and interests that fuel my creativity and passion.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {hobbies.map((hobby, i) => (
            <motion.div
              key={i}
              custom={i}
              variants={hobbyVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-all duration-300 bg-white dark:bg-gray-800 hover:scale-105">
                <CardContent className="p-6 text-center">
                  <div className="flex justify-center mb-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-full w-fit mx-auto">
                    {hobby.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3">{hobby.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-xs md:text-sm leading-relaxed text-center">
                    {hobby.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
