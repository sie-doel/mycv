"use client"

import { useState } from "react"
import { X, Play, ExternalLink } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface VideoProject {
  id: string
  title: string
  description: string
  thumbnail: string
  category: string
  date: string
  link?: string
}

export default function VideoPortfolioModal({
  isOpen,
  onClose,
}: {
  isOpen: boolean
  onClose: () => void
}) {
  const [activeCategory, setActiveCategory] = useState<string>("all")

  const videoProjects: VideoProject[] = [
    {
      id: "video1",
      title: "Mobile Legends Tournament Highlights",
      description: "Highlights from the EJR Entertainment Mobile Legends tournament featuring top plays and moments.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "esports",
      date: "June 2023",
      link: "https://www.instagram.com/ejr_entertainment.group/",
    },
    {
      id: "video2",
      title: "Travel Vlog: Bali Adventure",
      description: "A cinematic travel vlog showcasing the beautiful landscapes and culture of Bali, Indonesia.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "travel",
      date: "August 2023",
    },
    {
      id: "video3",
      title: "Product Showcase: Tech Gadgets",
      description: "A commercial video showcasing the latest tech gadgets with creative transitions and effects.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "commercial",
      date: "September 2023",
    },
    {
      id: "video4",
      title: "Free Fire Tournament Recap",
      description: "A recap of the Free Fire tournament organized by EJR Entertainment Group.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "esports",
      date: "October 2023",
      link: "https://www.instagram.com/ejr_entertainment.group/",
    },
    {
      id: "video5",
      title: "Short Film: The Journey",
      description: "A short narrative film exploring themes of personal growth and discovery.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "creative",
      date: "November 2023",
    },
    {
      id: "video6",
      title: "Data Visualization Explainer",
      description: "An educational video explaining complex data visualization techniques in a simple way.",
      thumbnail: "/placeholder.svg?height=200&width=350",
      category: "educational",
      date: "December 2023",
    },
  ]

  const categories = [
    { id: "all", name: "All Videos" },
    { id: "esports", name: "E-Sports" },
    { id: "travel", name: "Travel" },
    { id: "commercial", name: "Commercial" },
    { id: "creative", name: "Creative" },
    { id: "educational", name: "Educational" },
  ]

  const filteredVideos =
    activeCategory === "all" ? videoProjects : videoProjects.filter((video) => video.category === activeCategory)

  if (!isOpen) return null

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            className="relative w-full max-w-6xl max-h-[90vh] bg-white dark:bg-gray-900 rounded-lg shadow-xl overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-800">
              <h2 className="text-2xl font-bold text-black dark:text-white">Video Portfolio</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={onClose}
                className="rounded-full hover:bg-gray-200 dark:hover:bg-gray-800"
              >
                <X className="h-6 w-6" />
                <span className="sr-only">Close</span>
              </Button>
            </div>

            {/* Category Filters */}
            <div className="p-6 border-b border-gray-200 dark:border-gray-800 overflow-x-auto">
              <div className="flex space-x-2">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={activeCategory === category.id ? "default" : "outline"}
                    className={
                      activeCategory === category.id
                        ? "bg-black text-white hover:bg-gray-800 dark:bg-white dark:text-black dark:hover:bg-gray-200"
                        : "border-gray-300 dark:border-gray-700"
                    }
                    onClick={() => setActiveCategory(category.id)}
                  >
                    {category.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* Video Grid */}
            <div className="p-6 overflow-y-auto" style={{ maxHeight: "calc(90vh - 180px)" }}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredVideos.map((video) => (
                  <motion.div
                    key={video.id}
                    layout
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow duration-300"
                  >
                    <div className="relative h-48 overflow-hidden group">
                      <img
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Button
                          variant="outline"
                          size="icon"
                          className="rounded-full bg-white/20 backdrop-blur-sm border-white text-white hover:bg-white/30"
                        >
                          <Play className="h-8 w-8" fill="white" />
                          <span className="sr-only">Play video</span>
                        </Button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-lg font-semibold text-black dark:text-white">{video.title}</h3>
                        {video.link && (
                          <a
                            href={video.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-gray-600 dark:text-gray-400 hover:text-black dark:hover:text-white"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        )}
                      </div>
                      <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">{video.description}</p>
                      <div className="flex justify-between items-center">
                        <Badge
                          variant="outline"
                          className="bg-gray-200 text-gray-800 border-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                        >
                          {video.category.charAt(0).toUpperCase() + video.category.slice(1)}
                        </Badge>
                        <span className="text-xs text-gray-500 dark:text-gray-500">{video.date}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
