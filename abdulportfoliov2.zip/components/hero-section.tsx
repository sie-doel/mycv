"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Video, MapPin } from "lucide-react"
import { motion } from "framer-motion"
import VideoPortfolioModal from "./video-portfolio-modal"
import ClockWidget from "./clock-widget"

export default function HeroSection() {
  const [mounted, setMounted] = useState(false)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <>
      <section id="home" className="min-h-screen flex flex-col justify-center pt-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
              Hi, I'm <span className="text-black dark:text-white">Abdul Ghofur</span>
            </h1>
            <h2 className="text-xl md:text-2xl text-gray-600 dark:text-gray-400 mb-2">
              Junior Data Analyst | Aspiring Videographer | E-Sports Community Founder
            </h2>
            <div className="flex items-center text-gray-600 dark:text-gray-400 mb-6">
              <MapPin className="h-4 w-4 mr-1" />
              <span>Based in Samarinda, East Kalimantan, Indonesia</span>
            </div>
            <p className="text-base md:text-lg text-gray-700 dark:text-gray-300 mb-8 max-w-xl text-left md:text-justify leading-relaxed">
              A creative and curious individual developing skills in data analysis, videography, and public
              communication. Passionate about turning data, visuals, and ideas into impactful stories and solutions.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button
                className="bg-black hover:bg-gray-800 text-white"
                onClick={() => {
                  document.getElementById("contact")?.scrollIntoView({
                    behavior: "smooth",
                  })
                }}
              >
                Get in Touch <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                className="border-black text-black hover:bg-gray-100 dark:border-white dark:text-white dark:hover:bg-gray-800"
                onClick={() => setIsVideoModalOpen(true)}
              >
                <Video className="mr-2 h-4 w-4" /> Video Portfolio
              </Button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex flex-col items-center space-y-8"
          >
            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-black dark:border-white">
              <img src="/images/profile.jpg" alt="Abdul Ghofur" className="object-cover w-full h-full" />
            </div>

            {/* Clock Widget */}
            <ClockWidget />
          </motion.div>
        </div>
      </section>

      <VideoPortfolioModal isOpen={isVideoModalOpen} onClose={() => setIsVideoModalOpen(false)} />
    </>
  )
}
