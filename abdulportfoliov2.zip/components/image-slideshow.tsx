"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Pause, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SlideshowImage {
  id: string
  src: string
  alt: string
  title: string
  description: string
}

export default function ImageSlideshow() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)

  const images: SlideshowImage[] = [
    {
      id: "1",
      src: "/images/audio-mixer-tvri.png",
      alt: "Audio Mixing at TVRI Kaltim",
      title: "Professional Audio Production",
      description: "Working with audio mixing equipment at TVRI Kaltim television station",
    },
    {
      id: "2",
      src: "/images/danau-makroman.jpg",
      alt: "Lake at Makroman Road",
      title: "Danau Siang di Ujung Jalan Makroman",
      description: "A peaceful lake scene showcasing the natural beauty of Samarinda",
    },
    {
      id: "3",
      src: "/images/pantai-balikpapan.jpg",
      alt: "Dawn at Balikpapan Beach",
      title: "Pantai Subuh Balikpapan",
      description: "Capturing the serene moments of dawn at Balikpapan beach",
    },
    {
      id: "4",
      src: "/images/islamic-center-mahakam.png",
      alt: "Islamic Center across Mahakam River",
      title: "Islamic Center di Sebrang Sungai Mahakam",
      description: "Evening view of the Islamic Center across the Mahakam River during golden hour",
    },
    {
      id: "5",
      src: "/placeholder.svg?height=400&width=800",
      alt: "Team Collaboration",
      title: "Community Building",
      description: "Working with teams and building creative communities",
    },
  ]

  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex === images.length - 1 ? 0 : prevIndex + 1))
    }, 5000)

    return () => clearInterval(interval)
  }, [isPlaying, images.length])

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? images.length - 1 : currentIndex - 1)
  }

  const goToNext = () => {
    setCurrentIndex(currentIndex === images.length - 1 ? 0 : currentIndex + 1)
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
  }

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <div className="relative w-full max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-lg">
      {/* Main image display */}
      <div className="relative h-[500px] overflow-hidden bg-gray-100 dark:bg-gray-800">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -300 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <img
              src={images[currentIndex].src || "/placeholder.svg"}
              alt={images[currentIndex].alt}
              className="max-w-full max-h-full object-contain"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

            {/* Image info overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
              <h3 className="text-xl md:text-2xl font-bold mb-2">{images[currentIndex].title}</h3>
              <p className="text-gray-200 text-sm md:text-base">{images[currentIndex].description}</p>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Navigation arrows */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white rounded-full"
          onClick={goToPrevious}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white rounded-full"
          onClick={goToNext}
        >
          <ChevronRight className="h-6 w-6" />
        </Button>

        {/* Play/Pause button */}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 bg-black/20 hover:bg-black/40 text-white rounded-full"
          onClick={togglePlayPause}
        >
          {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
        </Button>
      </div>

      {/* Thumbnail navigation */}
      <div className="p-4 bg-gray-100 dark:bg-gray-700">
        <div className="flex space-x-2 overflow-x-auto">
          {images.map((image, index) => (
            <button
              key={image.id}
              onClick={() => goToSlide(index)}
              className={`flex-shrink-0 w-20 h-12 rounded overflow-hidden border-2 transition-all bg-gray-200 dark:bg-gray-600 flex items-center justify-center ${
                index === currentIndex ? "border-black dark:border-white" : "border-transparent hover:border-gray-400"
              }`}
            >
              <img
                src={image.src || "/placeholder.svg"}
                alt={image.alt}
                className="max-w-full max-h-full object-contain"
              />
            </button>
          ))}
        </div>
      </div>

      {/* Progress indicators */}
      <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {images.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex ? "bg-white" : "bg-white/50 hover:bg-white/75"
            }`}
          />
        ))}
      </div>
    </div>
  )
}
