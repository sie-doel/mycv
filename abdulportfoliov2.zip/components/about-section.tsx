"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Card, CardContent } from "@/components/ui/card"
import {
  Briefcase,
  Code,
  Video,
  Users,
  Lightbulb,
  BarChart,
  Wrench,
  Shield,
  Target,
  UsersIcon,
  ExternalLink,
} from "lucide-react"
import Link from "next/link"
import ImageSlideshow from "./image-slideshow"

export default function AboutSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      },
    }),
  }

  const cards = [
    {
      icon: <Code className="h-10 w-10 text-black dark:text-white" />,
      title: "Data Analysis",
      description: "Learning Python, R, and SPSS for data analysis and visualization.",
    },
    {
      icon: <Video className="h-10 w-10 text-black dark:text-white" />,
      title: "Videography",
      description: "Developing skills in video production and editing for creative projects.",
    },
    {
      icon: <Users className="h-10 w-10 text-black dark:text-white" />,
      title: "Communication",
      description: "Building public speaking abilities and English language skills.",
    },
    {
      icon: <Briefcase className="h-10 w-10 text-black dark:text-white" />,
      title: "Entrepreneurship",
      description: (
        <>
          Founder of{" "}
          <Link
            href="https://www.instagram.com/ejr_entertainment.group/"
            target="_blank"
            rel="noopener noreferrer"
            className="underline hover:text-gray-800 dark:hover:text-gray-200"
          >
            EJR Entertainment Group
          </Link>{" "}
          and experience in e-travel sector.
        </>
      ),
    },
  ]

  const strengths = [
    {
      icon: <Lightbulb className="h-6 w-6 text-black dark:text-white" />,
      title: "Creative Thinking",
      description: "Eager to contribute ideas and help move teams from discussion to action.",
    },
    {
      icon: <BarChart className="h-6 w-6 text-black dark:text-white" />,
      title: "Data-Curious",
      description: "Developing skills in data analysis using Python, R, and SPSS.",
    },
    {
      icon: <Wrench className="h-6 w-6 text-black dark:text-white" />,
      title: "Tools & Tech",
      description: "Learning to use CapCut, Adobe Premiere, Blender, Unreal Engine, Canva, Photoshop.",
    },
    {
      icon: <Shield className="h-6 w-6 text-black dark:text-white" />,
      title: "Honest & Reliable",
      description: "Value transparency and accountability in all collaborations.",
    },
    {
      icon: <Target className="h-6 w-6 text-black dark:text-white" />,
      title: "Solution-Oriented",
      description: "Focus on practical action and decision-making to solve problems.",
    },
    {
      icon: <UsersIcon className="h-6 w-6 text-black dark:text-white" />,
      title: "Team Player",
      description: "Believe that the best solutions come from collective minds — not solo efforts.",
    },
  ]

  return (
    <section id="about" className="py-20" ref={ref}>
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold mb-4">About Me</h2>
        <div className="w-20 h-1 bg-black dark:bg-white mx-auto mb-8"></div>
        <p className="max-w-3xl mx-auto text-lg text-gray-700 dark:text-gray-300">
          I'm a junior data analyst and visual content creator with a passion for learning and growth in both technical
          and creative fields.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, i) => (
          <motion.div
            key={i}
            custom={i}
            variants={cardVariants}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
          >
            <Card className="h-full border-none shadow-lg hover:shadow-xl transition-shadow duration-300 bg-white dark:bg-gray-800">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">{card.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{card.title}</h3>
                <p className="text-gray-600 dark:text-gray-400">{card.description}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="mt-16 bg-gray-100 dark:bg-gray-800 rounded-lg p-8">
        <h3 className="text-2xl font-bold mb-6">My Journey</h3>
        <div className="space-y-6 text-base md:text-lg text-gray-700 dark:text-gray-300 text-left md:text-justify leading-relaxed">
          <p>
            I am a passionate and ever-curious individual who believes that growth comes from constantly challenging
            oneself. As someone early in my career, I'm driven not by past accomplishments but by the desire to keep
            evolving. I'm always eager to try things I've never done before and believe that collaboration is key to
            solving complex problems. I enjoy participating in team discussions to contribute ideas and help bring
            visions to life.
          </p>
          <p>
            As a junior in the creative field, I'm developing my skills through video projects that involve various
            teams and locations. I'm particularly interested in short-form content for TikTok and Reels, and have been
            part of e-sports teams that have participated in tournaments. I'm currently building my technical skills
            with tools like CapCut, Adobe Premiere, Blender, Unreal Engine, Canva, Photoshop, and various data tools for
            analysis and visualization.
          </p>
          <p>
            I'm the founder of{" "}
            <Link
              href="https://www.instagram.com/ejr_entertainment.group/"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium underline hover:text-black dark:hover:text-white inline-flex items-center"
            >
              EJR Entertainment Group <ExternalLink className="ml-1 h-4 w-4" />
            </Link>
            , an e-sports community managing competitive teams in Mobile Legends, Free Fire, and eFootball. My journey
            also includes leading trips in the e-travel sector, managing intercity expedition services, and working on
            various video and photography projects for creative purposes.
          </p>
        </div>
      </div>

      <div className="mt-16">
        <h3 className="text-2xl font-bold mb-8 text-center">Visual Journey</h3>
        <ImageSlideshow />
      </div>

      <div className="mt-12">
        <h3 className="text-2xl font-bold mb-8 text-center">Key Strengths & Work Style</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {strengths.map((strength, i) => (
            <motion.div
              key={i}
              custom={i}
              variants={cardVariants}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <Card className="h-full border-none shadow-md hover:shadow-lg transition-shadow duration-300 bg-white dark:bg-gray-800">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="mr-4 p-2 bg-gray-100 dark:bg-gray-700 rounded-full">{strength.icon}</div>
                    <h4 className="text-lg font-semibold">{strength.title}</h4>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">{strength.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        <div className="mt-8 p-6 bg-black text-white dark:bg-white dark:text-black rounded-lg text-center">
          <p className="text-lg font-medium italic">
            "Known as determined and action oriented I help move projects forward rather than getting stuck in endless
            discussion."
          </p>
        </div>
      </div>
    </section>
  )
}
