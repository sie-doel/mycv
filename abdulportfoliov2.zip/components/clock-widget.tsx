"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

export default function ClockWidget() {
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getRotation = (value: number, max: number) => {
    return (value / max) * 360
  }

  const hours = time.getHours() % 12
  const minutes = time.getMinutes()
  const seconds = time.getSeconds()

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Analog Clock */}
      <div className="relative w-32 h-32 bg-white dark:bg-gray-800 rounded-full shadow-lg border-4 border-gray-200 dark:border-gray-700">
        {/* Clock face numbers */}
        {[...Array(12)].map((_, i) => {
          const angle = i * 30 - 90
          const x = 50 + 35 * Math.cos((angle * Math.PI) / 180)
          const y = 50 + 35 * Math.sin((angle * Math.PI) / 180)
          return (
            <div
              key={i}
              className="absolute text-xs font-bold text-gray-700 dark:text-gray-300"
              style={{
                left: `${x}%`,
                top: `${y}%`,
                transform: "translate(-50%, -50%)",
              }}
            >
              {i === 0 ? 12 : i}
            </div>
          )
        })}

        {/* Hour hand */}
        <motion.div
          className="absolute w-0.5 bg-gray-800 dark:bg-gray-200 origin-bottom"
          style={{
            height: "25%",
            left: "50%",
            top: "25%",
            transformOrigin: "bottom center",
          }}
          animate={{
            rotate: getRotation(hours + minutes / 60, 12),
          }}
          transition={{ type: "spring", stiffness: 100 }}
        />

        {/* Minute hand */}
        <motion.div
          className="absolute w-0.5 bg-gray-600 dark:bg-gray-400 origin-bottom"
          style={{
            height: "35%",
            left: "50%",
            top: "15%",
            transformOrigin: "bottom center",
          }}
          animate={{
            rotate: getRotation(minutes + seconds / 60, 60),
          }}
          transition={{ type: "spring", stiffness: 100 }}
        />

        {/* Second hand */}
        <motion.div
          className="absolute w-0.5 bg-red-500 origin-bottom"
          style={{
            height: "40%",
            left: "50%",
            top: "10%",
            transformOrigin: "bottom center",
          }}
          animate={{
            rotate: getRotation(seconds, 60),
          }}
          transition={{ type: "spring", stiffness: 200 }}
        />

        {/* Center dot */}
        <div className="absolute w-3 h-3 bg-gray-800 dark:bg-gray-200 rounded-full top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
      </div>

      {/* Digital time and date */}
      <div className="text-center">
        <div className="text-2xl font-mono font-bold text-black dark:text-white">{formatTime(time)}</div>
        <div className="text-sm text-gray-600 dark:text-gray-400">{formatDate(time)}</div>
      </div>
    </div>
  )
}
