"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SkillsSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const technicalSkills = [
    { name: "Python", level: 65 },
    { name: "R", level: 60 },
    { name: "SPSS", level: 55 },
    { name: "Data Analysis", level: 70 },
    { name: "Video Editing", level: 75 },
    { name: "Photography", level: 70 },
  ]

  const softSkills = [
    { name: "Public Speaking", level: 80 },
    { name: "English Language", level: 75 },
    { name: "Team Management", level: 70 },
    { name: "Project Management", level: 65 },
    { name: "Problem Solving", level: 75 },
    { name: "Communication", level: 80 },
  ]

  const tools = [
    { name: "CapCut", level: 75 },
    { name: "Adobe Premiere", level: 65 },
    { name: "Blender", level: 50 },
    { name: "Unreal Engine", level: 45 },
    { name: "Canva", level: 80 },
    { name: "Photoshop", level: 60 },
  ]

  const skillVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      },
    }),
  }

  return (
    <section id="skills" className="py-20 bg-gray-50 dark:bg-gray-900 rounded-lg" ref={ref}>
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">My Skills</h2>
          <div className="w-20 h-1 bg-black dark:bg-white mx-auto mb-8"></div>
          <p className="max-w-3xl mx-auto text-base md:text-lg text-gray-700 dark:text-gray-300 leading-relaxed px-4 text-center">
            As a junior in data and visual fields, I'm actively developing these skills and always eager to learn more.
          </p>
        </div>

        <Tabs defaultValue="technical" className="w-full">
          <div className="flex justify-center mb-8">
            <TabsList className="bg-gray-200 dark:bg-gray-800">
              <TabsTrigger value="technical">Technical Skills</TabsTrigger>
              <TabsTrigger value="tools">Tools & Software</TabsTrigger>
              <TabsTrigger value="soft">Soft Skills</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="technical" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {technicalSkills.map((skill, i) => (
                <motion.div
                  key={skill.name}
                  custom={i}
                  variants={skillVariants}
                  initial="hidden"
                  animate={inView ? "visible" : "hidden"}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span>{skill.level}%</span>
                  </div>
                  <Progress
                    value={skill.level}
                    className="h-2 bg-gray-200 dark:bg-gray-700"
                    indicatorClassName="bg-black dark:bg-white"
                  />
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="tools" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {tools.map((tool, i) => (
                <motion.div
                  key={tool.name}
                  custom={i}
                  variants={skillVariants}
                  initial="hidden"
                  animate={inView ? "visible" : "hidden"}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{tool.name}</span>
                    <span>{tool.level}%</span>
                  </div>
                  <Progress
                    value={tool.level}
                    className="h-2 bg-gray-200 dark:bg-gray-700"
                    indicatorClassName="bg-black dark:bg-white"
                  />
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="soft" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {softSkills.map((skill, i) => (
                <motion.div
                  key={skill.name}
                  custom={i}
                  variants={skillVariants}
                  initial="hidden"
                  animate={inView ? "visible" : "hidden"}
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{skill.name}</span>
                    <span>{skill.level}%</span>
                  </div>
                  <Progress
                    value={skill.level}
                    className="h-2 bg-gray-200 dark:bg-gray-700"
                    indicatorClassName="bg-black dark:bg-white"
                  />
                </motion.div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  )
}
