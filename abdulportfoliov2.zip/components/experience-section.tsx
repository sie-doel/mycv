"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Calendar, Gamepad2, Camera, Plane, ExternalLink, BarChart3, Truck } from "lucide-react"
import Link from "next/link"

export default function ExperienceSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const experiences = [
    {
      title: "Independent Data Analyst (Self-Development Phase)",
      company: "Freelance & Learning Journey",
      companyLink: "",
      period: "2024 - Present",
      description:
        "Currently deepening knowledge in data analysis using Python, R, and SPSS. Working on personal and freelance projects involving data visualization, predictive analytics, and dashboard design. Focused on bridging data insights with storytelling and business strategy.",
      icon: <BarChart3 className="h-6 w-6 text-black dark:text-white" />,
    },
    {
      title: "Founder – Intercity Expedition Service",
      company: "Logistics & Delivery",
      companyLink: "",
      period: "2023 - Present",
      description:
        "Launched and currently manage a delivery service operating between cities. Designed operational workflows, managed delivery routes, and led a small team to ensure customer satisfaction. Implemented improvements in logistics handling and client communication.",
      icon: <Truck className="h-6 w-6 text-black dark:text-white" />,
    },
    {
      title: "Team Member – E-Travel Development Project",
      company: "Collaborative Travel Project",
      companyLink: "",
      period: "2022",
      description:
        "Joined a development team focused on expanding digital travel services post-high school graduation. Contributed to itinerary design, digital marketing, and coordination with travel partners.",
      icon: <Plane className="h-6 w-6 text-black dark:text-white" />,
    },
    {
      title: "Founder – EJR Entertainment Group",
      company: "EJR Entertainment Group",
      companyLink: "https://www.instagram.com/ejr_entertainment.group/",
      period: "2021 - Present",
      description:
        "Established and grew a creative community combining esports teams and digital content production. Managed competitive teams across Mobile Legends, Free Fire, and eFootball. Oversaw social media content strategy, including short-form video production for TikTok and Instagram.",
      icon: <Camera className="h-6 w-6 text-black dark:text-white" />,
    },
    {
      title: "Esports Team Founder",
      company: "Independent Project",
      companyLink: "",
      period: "2020",
      description:
        "Built and led an esports team from the ground up, focusing on games like Mobile Legends and Free Fire. Organized internal scrims, developed training routines, and built early team discipline and synergy.",
      icon: <Gamepad2 className="h-6 w-6 text-black dark:text-white" />,
    },
  ]

  const experienceVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.2 * i,
        duration: 0.6,
      },
    }),
  }

  return (
    <section id="experience" className="py-20" ref={ref}>
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Professional Experience</h2>
          <div className="w-20 h-1 bg-black dark:bg-white mx-auto mb-8"></div>
          <p className="max-w-3xl mx-auto text-lg text-gray-700 dark:text-gray-300">
            My professional journey across various industries and roles, from esports to data analysis.
          </p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-1 bg-gray-300 dark:bg-gray-700"></div>

          <div className="space-y-12">
            {experiences.map((exp, i) => (
              <motion.div
                key={i}
                custom={i}
                variants={experienceVariants}
                initial="hidden"
                animate={inView ? "visible" : "hidden"}
                className={`relative flex flex-col md:flex-row ${i % 2 === 0 ? "md:flex-row-reverse" : ""}`}
              >
                <div className="md:w-1/2"></div>

                {/* Timeline dot */}
                <div className="absolute left-0 md:left-1/2 transform -translate-y-1/2 md:-translate-x-1/2 w-6 h-6 rounded-full bg-black dark:bg-white z-10 flex items-center justify-center">
                  <div className="w-3 h-3 rounded-full bg-white dark:bg-gray-900"></div>
                </div>

                <div
                  className={`md:w-1/2 bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg ml-8 md:ml-0 ${
                    i % 2 === 0 ? "md:mr-8" : "md:ml-8"
                  }`}
                >
                  <div className="flex items-center mb-3">
                    {exp.icon}
                    <h3 className="text-xl font-bold ml-2">{exp.title}</h3>
                  </div>
                  <h4 className="text-lg font-semibold text-black dark:text-white mb-2">
                    {exp.companyLink ? (
                      <Link
                        href={exp.companyLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center hover:underline"
                      >
                        {exp.company}
                        <ExternalLink className="ml-1 h-4 w-4" />
                      </Link>
                    ) : (
                      exp.company
                    )}
                  </h4>
                  <div className="flex items-center text-gray-600 dark:text-gray-400 mb-4">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>{exp.period}</span>
                  </div>
                  <p className="text-sm md:text-base text-gray-700 dark:text-gray-300 text-left md:text-justify leading-relaxed">
                    {exp.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
